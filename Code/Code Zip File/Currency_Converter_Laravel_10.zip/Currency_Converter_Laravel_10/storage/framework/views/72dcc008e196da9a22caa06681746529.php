

<?php $__env->startSection('title', 'Update User'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container my-4">
        <h2 class="text-center mb-4">Update User</h2>
        
        <form method="post" action="<?php echo e(route('admin.user_update')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" class="form-control" id="username" name="username" value="<?php echo e($user->username); ?>" required>
                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="password" value="<?php echo e($user->plain_password); ?>" placeholder="Leave blank to keep the current password">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="roles">Roles</label>
                <select class="form-control" id="roles" name="roles[]" multiple>
                    <option value="ROLE_USER" <?php echo e(in_array('ROLE_USER', $user->roles) ? 'selected' : ''); ?>>ROLE_USER</option>
                    <option value="ROLE_ADMIN" <?php echo e(in_array('ROLE_ADMIN', $user->roles) ? 'selected' : ''); ?>>ROLE_ADMIN</option>
                </select>
            </div>

            <input type="hidden" name="id" value="<?php echo e(session('id')); ?>">

            <button type="submit" class="btn btn-primary">Update</button>
            <a href="<?php echo e(route('admin.user_management_form')); ?>" class="btn btn-secondary">Cancel</a>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Currency_Converter_Laravel_10\resources\views/user_update.blade.php ENDPATH**/ ?>