

<?php $__env->startSection('title', 'Currencies Export'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container my-4">
        <h2>Currencies Export</h2>

        <div class="row">
            <!-- Export to Excel -->
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Export to Excel</h5>
                        <form action="<?php echo e(route('currencies.export_excel')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('POST'); ?>
                            <div class="form-group">
                                <label for="excelFileName">File Name (Optional)</label>
                                <input type="text" class="form-control" id="excelFileName" name="excel_file_name" placeholder="Enter file name (leave empty for auto-generated)">
                                <?php $__errorArgs = ['excel_file_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <button type="submit" class="btn btn-primary custom-btn" name="export_excel">Export to Excel</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Export to Database -->
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Export to Database</h5>
                        <form action="<?php echo e(route('currencies.export_database')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('POST'); ?>
                            <div class="form-group">
                                <label for="dbHost">Database Host</label>
                                <input type="text" class="form-control" id="dbHost" name="db_host" placeholder="e.g., localhost" required>
                                <?php $__errorArgs = ['db_host'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="dbPort">Database Port</label>
                                <input type="number" class="form-control" id="dbPort" name="db_port" placeholder="e.g., 3306" required>
                                <?php $__errorArgs = ['db_port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="dbName">Database Name</label>
                                <input type="text" class="form-control" id="dbName" name="db_name" placeholder="e.g., my_database" required>
                                <?php $__errorArgs = ['db_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="dbTableName">Table Name (Optional)</label>
                                <input type="text" class="form-control" id="dbTableName" name="db_table_name" placeholder="Enter table name (leave empty for default)">
                                <?php $__errorArgs = ['db_table_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="dbUsername">Username</label>
                                <input type="text" class="form-control" id="dbUsername" name="db_username" placeholder="e.g., root" required>
                                <?php $__errorArgs = ['db_username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="dbPassword">Password</label>
                                <input type="password" class="form-control" id="dbPassword" name="db_password" placeholder="e.g., password">
                                <?php $__errorArgs = ['db_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <button type="button" class="btn btn-secondary" id="setDefaults">Set Default Values</button>
                            <button type="submit" class="btn btn-primary custom-btn" name="export_database">Export to Database</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/currencies_export.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Currency_Converter_Laravel_10\resources\views/currencies_export.blade.php ENDPATH**/ ?>