<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?></title>
    <!-- Bootstrap 4 CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>


</head>

<body>
    <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('currency.converter_form','currency.converter') ? 'active' : ''); ?>" href="<?php echo e(route('currency.converter_form', $role)); ?>">Currency Converter</a>
                </li>
                <?php if($role == 'admin'): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('admin.user_management_form','admin.user_update_form') ? 'active' : ''); ?>" href="<?php echo e(route('admin.user_management_form')); ?>">User Management</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('ip.management') ? 'active' : ''); ?>" href="<?php echo e(route('ip.management')); ?>">IP Management</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('currencies.export') ? 'active' : ''); ?>" href="<?php echo e(route('currencies.export')); ?>">Currencies Export</a>
                </li>
                <?php endif; ?>
                <li class="nav-item nav-link"><?php echo e($username); ?>

                </li>
                <li class="nav-item">
                    <a class="nav-link btn-logout" href="<?php echo e(route('logout')); ?>">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <?php if(Session::has('error')): ?>
        <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
    <?php endif; ?>

    <?php if(Session::has('success')): ?>
        <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
    <?php endif; ?>

    <div class="container my-4">
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->yieldContent('scripts'); ?>

    </div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Currency_Converter_Laravel_10\resources\views/dashboard.blade.php ENDPATH**/ ?>