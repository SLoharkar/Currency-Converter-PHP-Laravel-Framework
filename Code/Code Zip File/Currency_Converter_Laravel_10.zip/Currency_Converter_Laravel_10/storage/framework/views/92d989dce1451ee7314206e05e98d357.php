

<?php $__env->startSection('title', 'Database Backup'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container my-4">
        <div class="row">
            <div class="col-md-6 mx-auto">
                <h2 class="text-center mb-4">Database Backup</h2>
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Create Backup</h5>
                        <form action="<?php echo e(route('backup')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="fileName">Backup File Name (Leave empty for auto-generated)</label>
                                <input type="text" class="form-control" id="fileName" name="file_name" placeholder="Enter backup file name">
                            </div>
                            <div class="form-group">
                                <label for="format">Backup Format</label>
                                <select id="format" name="format" class="form-control" required>
                                    <option value="json">JSON</option>
                                    <option value="csv">CSV</option>
                                    <option value="pdf">PDF</option>
                                    <option value="sql">SQL</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Backup Database</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Currency_Converter_Laravel_10\resources\views/backup.blade.php ENDPATH**/ ?>