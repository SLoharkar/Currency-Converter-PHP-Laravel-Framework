

<?php $__env->startSection('title', 'IP Address Management'); ?>

<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
<?php endif; ?>

<div class="container mt-5">
    <h2>IP Address Management</h2>

    <!-- Form for adding a new IP address -->
    <form action="<?php echo e(route('ip.management_add')); ?>" method="POST" class="form-inline mb-3">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
        <div class="form-group mx-sm-3 mb-2">
            <input type="text" name="ip_address" class="form-control mr-2" placeholder="Enter IP Address" value="192.168.1.1" required>
        </div>
        <button type="submit" class="btn btn-primary mb-2">Add</button>
    </form>

    <!-- Table to display the list of IP addresses -->
    <table class="table table-bordered" style="width: 40%;">
        <thead>
            <tr>
                <th class="text-center">IP Address</th>
                <th class="text-center">Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $ipAddresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ipAddress): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <!-- Form for updating the IP address -->
                        <form action="<?php echo e(route('ip.management_update')); ?>" method="POST" class="d-flex align-items-center">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <input type="text" name="ip_address" class="form-control mr-2" value="<?php echo e($ipAddress->ip_address); ?>">
                            <input type="hidden" name="id" value="<?php echo e($ipAddress->id); ?>">
                            <button type="submit" class="btn btn-success">Update</button>
                        </form>
                    </td>
                    <td>
                        <!-- Form for deleting the IP address -->
                        <form action="<?php echo e(route('ip.management_del')); ?>" method="POST" class="d-inline-block">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="hidden" name="id" value="<?php echo e($ipAddress->id); ?>">
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Currency_Converter_Laravel_10\resources\views/ip_management.blade.php ENDPATH**/ ?>