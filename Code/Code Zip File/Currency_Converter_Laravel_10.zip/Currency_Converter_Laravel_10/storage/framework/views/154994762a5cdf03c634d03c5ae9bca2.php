

<?php $__env->startSection('title', 'User Management'); ?>

<?php $__env->startSection('content'); ?>
    <h2 class="text-center mb-4">User Management</h2>
    
    <!-- Table displaying user data -->
    <table class="table table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>Username</th>
                <th>Password</th>
                <th>Roles</th>
                <th colspan="2" class="text-center">Actions</th>
            </tr>
        </thead>
        <tbody>
            <!-- Iterate over users passed from the controller -->
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->username); ?></td>
                <td><?php echo e($user->plain_password); ?></td>
                <td><?php echo e(implode(', ', $user->roles)); ?></td>
                <td class="text-center">
                    <form action="<?php echo e(route('admin.user_update_form')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                </td>
                <td class="text-center">
                    <form action="<?php echo e(route('admin.user_delete')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Currency_Converter_Laravel_10\resources\views/user_management.blade.php ENDPATH**/ ?>